Creative Commons Zero v1.0 Universal

Use without any limitation for personal and commercial. All source file available to download for free.
---
PERMISSIONS:
*Commercial use
*Modification
*Distribution
*Private use
---
The Creative Commons CC0 Public Domain Dedication waives copyright interest in a work you've created and dedicates it to the world-wide public domain. Use CC0 to opt out of copyright entirely and ensure your work has the widest reach. As with the Unlicense and typical software licenses, CC0 disclaims warranties. CC0 is very similar to the Unlicense.


For more information, please see
<http://creativecommons.org/publicdomain/zero/1.0/>
